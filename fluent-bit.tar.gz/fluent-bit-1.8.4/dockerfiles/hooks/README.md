## post_checkout

qemu static release binaries taken from:

https://github.com/multiarch/qemu-user-static
